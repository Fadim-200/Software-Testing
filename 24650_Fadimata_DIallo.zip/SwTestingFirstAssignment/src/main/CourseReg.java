package main;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class CourseReg {
	 public static void main(String[] args) throws IOException {
	        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
	        boolean continueExecution = true;

	        while (continueExecution) {
	            System.out.println("============================ ====================== ============================");
	            System.out.println("============================ COURSE REGISTRATION SYSTEM ============================");
	            System.out.println("============================ ====================== ============================");

	            System.out.println("Select an option:\n1.Record new Course\n2.List courses\n3.Edit course information\n4.Delete course\n0.Exit\n");

	            int choice = Integer.parseInt(reader.readLine());

	            switch (choice) {
	                case 1:
	                    System.out.println("Id: ");
	                    int id = Integer.parseInt(reader.readLine());
	                    System.out.println("Course Name: ");
	                    String coursename = reader.readLine();

	                    createCourse(id, coursename);
	                    break;
	                case 2:
	                    listCourses();
	                    break;
	                case 3:
	                    System.out.println("Courses Id:");
	                    listCourses();
	                    System.out.println("Course Id: ");
	                    int Id = Integer.parseInt(reader.readLine());
	                    System.out.println("Course Name: ");
	                    String newName = reader.readLine();

	                    updateCourse(Id, newName);
	                    break;
	                case 4:
	                    listCourses();
	                    System.out.println("Course Id: ");
	                    int Course_Id = Integer.parseInt(reader.readLine());
	                    deleteCourse(Course_Id);
	                    break;
	                case 0:
	                    continueExecution = false;
	                    break;
	                default:
	                    System.out.println("wrong choice, Try again.");
	                    break;
	            }

	            if (continueExecution) {
	                System.out.println("Do you want to continue? (yes/no)");
	                String continueChoice = reader.readLine().toLowerCase();
	                if (!continueChoice.equals("yes")) {
	                    continueExecution = false;
	                }
	            }
	        }
	 }
	public static Connection makeConnection() {
	    try {
	        Class.forName("com.mysql.cj.jdbc.Driver");
	        Connection con = DriverManager.getConnection(
	        	    "jdbc:mysql://localhost:3306/studentdb?serverTimezone=Africa/Kigali",
	        	    "root",
	        	    "ipegFa20032014");
	        return con;
	    }
	    catch (Exception e) {
	        e.printStackTrace();
	        return null;
	    }
	}
	public static void createCourse(int id, String coursename) {
	    try {
	        String sql = "INSERT INTO courses (course_id, course_name) VALUES (?, ?)";
	        Connection con = makeConnection(); // establish connection

	        PreparedStatement statement = con.prepareStatement(sql);
	        // set values
	        statement.setInt(1, id);
	        statement.setString(2, coursename);

	        // count affected rows and return the count
	        int rowsAffected = statement.executeUpdate();
	        if(rowsAffected>=1)
	        {
	        	System.out.println("Course recorded");
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	      
	    }
	}

	public static void listCourses() {
	    try {
	        String sql = "SELECT * FROM courses";
	        Connection con = makeConnection(); // establish connection
	        PreparedStatement statement = con.prepareStatement(sql);

	        ResultSet result = statement.executeQuery();
	        while (result.next()) {
	            int id = result.getInt("course_id");
	            String CourseName = result.getString("course_name");

	            System.out.print(" Course Id: " + id);
	            System.out.println("\n");
	            System.out.print("  Course Name: " + CourseName);
	            System.out.println("\n");
	            System.out.println("----------------------------\n");
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	}

	public static void updateCourse(int id, String course_name) {
	    try {
	        String sql = "UPDATE courses SET course_name = ? WHERE course_id = ?";
	        Connection con = makeConnection(); // establish connection

	        PreparedStatement statement = con.prepareStatement(sql);
	        statement.setString(1, course_name);
	        statement.setInt(2, id);

	        // count affected rows and return the count
	        int rowsAffected = statement.executeUpdate();
	        if (rowsAffected >= 1)
	            System.out.println("Course information updated");
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	}
	public static void deleteCourse(int id) {
	    try {
	        String sql = "DELETE  FROM courses WHERE course_id = ?";
	        Connection con = makeConnection(); // establish connection
	        PreparedStatement statement = con.prepareStatement(sql);
	        statement.setInt(1, id);

	        // count affected rows and return the count
	        int rowsAffected = statement.executeUpdate();
	        if (rowsAffected >= 1)
	            System.out.println("Course deleted");
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	}
}
