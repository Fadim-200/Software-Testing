package main;

import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.After;
import org.junit.Before;

//import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.PrintStream;
//import java.sql.*;
//import java.sql.DriverManager;
//import java.sql.SQLException;
//
//import static org.junit.Assert.assertEquals;
//import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
public class StudentRegTesting {

//	@Test
//	public void test(){
//	fail("Not yet implemented");
//	}/
	 private final ByteArrayOutputStream outContent = new ByteArrayOutputStream();
	    private final PrintStream originalOut = System.out;
	    private final InputStream originalIn = System.in;

	    @Before
	    public void setUpStreams() {
	        System.setOut(new PrintStream(outContent));
	    }

	    @After
	    public void restoreStreams() {
	        System.setOut(originalOut);
	        System.setIn(originalIn);
	    }

	    @Test
	    public void testCreateStudent() {
	        StudentRegistration.createStudent(101, "John", "Doe");
	        // Verify by checking console output
	        assertTrue(outContent.toString().contains("Student recorded"));
	    }

	    @Test
	    public void testListStudents() {
	        // Redirect System.out for testing
	        System.setOut(new PrintStream(outContent));
	        StudentRegistration.listStudents();
	        // Verify by checking console output
	        assertTrue(outContent.toString().contains("Id"));
	    }

	    @Test
	    public void testUpdateStudent() {
	        StudentRegistration.updateStudent(101, "Jane", "Doe");
	        // Verify by checking console output
	        assertTrue(outContent.toString().contains("Student information updated"));
	    }

	    @Test
	    public void testDeleteStudent() {
	        StudentRegistration.deleteStudent(101);
	        // Verify by checking console output
	        assertTrue(outContent.toString().contains("Student deleted"));
	    }
}
