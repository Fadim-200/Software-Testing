package main;

import static org.junit.Assert.*;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.PrintStream;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class CourseTesting {

	/*
	 * @Test public void test() { fail("Not yet implemented"); }
	 */

	 private final ByteArrayOutputStream outContent = new ByteArrayOutputStream();
	    private final PrintStream originalOut = System.out;
	    private final InputStream originalIn = System.in;

	    @Before
	    public void setUpStreams() {
	        System.setOut(new PrintStream(outContent));
	    }

	    @After
	    public void restoreStreams() {
	        System.setOut(originalOut);
	        System.setIn(originalIn);
	    }

	    @Test
	    public void testCreateCourrse() {
	        CourseReg.createCourse(404, "Software Testing");
	        // Verify by checking console output
	        assertTrue(outContent.toString().contains("Course recorded"));
	    }

	    @Test
	    public void testListCourses() {
	        // Redirect System.out for testing
	        System.setOut(new PrintStream(outContent));
	        CourseReg.listCourses();
	        // Verify by checking console output
	        assertTrue(outContent.toString().contains("Id"));
	    }

	    @Test
	    public void testUpdateCourse() {
	    	CourseReg.updateCourse(404, "Web Tech");
	        // Verify by checking console output
	        assertTrue(outContent.toString().contains("Course information updated"));
	    }

	    @Test
	    public void testDeleteCourse() {
	    	CourseReg.deleteCourse(404);
	        // Verify by checking console output
	        assertTrue(outContent.toString().contains("Course deleted"));
	    }
}
