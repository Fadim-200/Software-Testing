package main;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.*;

public class StudentRegistration {
	
	 public static void main(String[] args) throws IOException {
	        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
	        boolean continueExecution = true;

	        while (continueExecution) {
	            System.out.println("============================ ====================== ============================");
	            System.out.println("============================ STUDENT REGISTRATION SYSTEM ============================");
	            System.out.println("============================ ====================== ============================");

	            System.out.println("Select an option:\n1.Record new Student\n2.List students\n3.Edit student information\n4.Delete student\n0.Exit\n");

	            int choice = Integer.parseInt(reader.readLine());

	            switch (choice) {
	                case 1:
	                    System.out.println("Id: ");
	                    int id = Integer.parseInt(reader.readLine());
	                    System.out.println("First Name: ");
	                    String firstname = reader.readLine();
	                    System.out.println("Last Name: ");
	                    String lastname = reader.readLine();

	                    createStudent(id, firstname, lastname);
	                    break;
	                case 2:
	                    listStudents();
	                    break;
	                case 3:
	                    System.out.println("Students Id:");
	                    listStudents();
	                    System.out.println("Student Id: ");
	                    int stId = Integer.parseInt(reader.readLine());
	                    System.out.println("First Name: ");
	                    String newName = reader.readLine();
	                    System.out.println("Last Name: ");
	                    String newlastname = reader.readLine();
	                    updateStudent(stId, newName, newlastname);
	                    break;
	                case 4:
	                    listStudents();
	                    System.out.println("Student Id: ");
	                    int Id = Integer.parseInt(reader.readLine());
	                    deleteStudent(Id);
	                    break;
	                case 0:
	                    continueExecution = false;
	                    break;
	                default:
	                    System.out.println("wrong choice, Try again.");
	                    break;
	            }

	            if (continueExecution) {
	                System.out.println("Do you want to continue? (yes/no)");
	                String continueChoice = reader.readLine().toLowerCase();
	                if (!continueChoice.equals("yes")) {
	                    continueExecution = false;
	                }
	            }
	        }
	    }
public static Connection makeConnection() {
    try {
        Class.forName("com.mysql.cj.jdbc.Driver");
        Connection con = DriverManager.getConnection(
        	    "jdbc:mysql://localhost:3306/studentdb?serverTimezone=Africa/Kigali",
        	    "root",
        	    "ipegFa20032014");
        return con;
    }
    catch (Exception e) {
        e.printStackTrace();
        return null;
    }
}
public static void createStudent(int id, String firstname, String lastname) {
    try {
        String sql = "INSERT INTO students (id, firstname, lastname) VALUES (?, ?, ?)";
        Connection con = makeConnection(); // establish connection

        PreparedStatement statement = con.prepareStatement(sql);
        // set values
        statement.setInt(1, id);
        statement.setString(2, firstname);
        statement.setString(3, lastname);

        // count affected rows and return the count
        int rowsAffected = statement.executeUpdate();
        if(rowsAffected>=1)
        {
        	System.out.println("Student recorded");
        }
    } catch (SQLException e) {
        e.printStackTrace();
      
    }
}

public static void listStudents() {
    try {
        String sql = "SELECT * FROM students";
        Connection con = makeConnection(); // establish connection
        PreparedStatement statement = con.prepareStatement(sql);

        ResultSet result = statement.executeQuery();
        while (result.next()) {
            int id = result.getInt("id");
            String firstname = result.getString("firstname");
            String lastname = result.getString("lastname");

            System.out.print("Id: " + id);
            System.out.print("\n");
            System.out.print("Fist Name: " + firstname);
            System.out.print("\n");

            System.out.print("Last Name: " + lastname);
            System.out.print("\n---------------------------\n");
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
}

public static void updateStudent(int id, String firstname, String lastname) {
    try {
        String sql = "UPDATE students SET firstname = ?, lastname= ? WHERE id = ?";
        Connection con = makeConnection(); // establish connection

        PreparedStatement statement = con.prepareStatement(sql);
        statement.setString(1, firstname);
        statement.setString(2, lastname);
        statement.setInt(3, id);

        // count affected rows and return the count
        int rowsAffected = statement.executeUpdate();
        if (rowsAffected >= 1)
            System.out.println("Student information updated");
    } catch (SQLException e) {
        e.printStackTrace();
    }
}
public static void deleteStudent(int id) {
    try {
        String sql = "DELETE FROM students WHERE id = ?";
        Connection con = makeConnection(); // establish connection
        PreparedStatement statement = con.prepareStatement(sql);
        statement.setInt(1, id);

        // count affected rows and return the count
        int rowsAffected = statement.executeUpdate();
        if (rowsAffected >= 1)
            System.out.println("Student deleted");
    } catch (SQLException e) {
        e.printStackTrace();
    }
}
}
